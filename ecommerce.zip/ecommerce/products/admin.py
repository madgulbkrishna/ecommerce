from django.contrib import admin
from .models import Product

class SnippetAdmin(admin.ModelAdmin):
    list_display = ('title', 'description', 'price')

admin.site.register(Product, SnippetAdmin)